# Secure E-commerce Website
### To run website using VSCode
- [Watch this video](https://youtu.be/Ry8tRRfxxf4?si=SG0XCl-WfShGnWjD).