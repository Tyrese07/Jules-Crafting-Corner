<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>My E-commerce Website</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <h1>Welcome to my E-commerce Website</h1>
    <?php echo 'This iiiiis php code'; ?>
</body>
</html>
